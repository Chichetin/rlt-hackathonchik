// Uses the repository's existing Playwright installation; no new dependency.
import { chromium } from '../../src/ui/node_modules/playwright-core/index.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const out = path.join(here, 'screens'); fs.mkdirSync(out, { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--disable-gpu'] });
const context = await browser.newContext({ viewport: { width: 1600, height: 900 }, offline: true });
const page = await context.newPage();
const errors = [], network = [], assertions = [];
page.on('pageerror', e => errors.push(String(e)));
page.on('request', r => { if (/^https?:/.test(r.url())) network.push(r.url()); });
function assert(value, message) { assertions.push({ check: message, passed: !!value }); if (!value) throw new Error(message); }
await page.goto(pathToFileURL(path.join(root, 'index.html')).href);
await page.evaluate(() => document.fonts.ready);
const inventory = await page.locator('.slide').evaluateAll(slides => slides.map(s => ({id:s.id, seconds:+s.dataset.seconds, kind:s.dataset.kind})));
assert(inventory.filter(s => s.kind === 'main').length === 7, 'Exactly 7 main slides');
assert(inventory.filter(s => s.kind === 'backup').length === 5, 'Exactly 5 backup slides');
assert(inventory.reduce((a,s) => a+s.seconds,0) === 300, 'Main timing = 300 seconds');
const layouts = [];
for (const s of inventory) {
  await page.evaluate(id => { location.hash = id+'/0'; }, s.id);
  await page.waitForFunction(id => !document.getElementById(id).hidden, s.id);
  await page.waitForTimeout(180);
  await page.screenshot({animations:'disabled',path:path.join(out,s.id+'.png')});
  const layout = await page.evaluate(id => {
    const slide=document.getElementById(id),sr=slide.getBoundingClientRect();
    const issues=[];
    const walker=document.createTreeWalker(slide,NodeFilter.SHOW_TEXT);
    while(walker.nextNode()){
      const n=walker.currentNode,el=n.parentElement;
      if(!n.textContent.trim()||el.closest('[hidden]'))continue;
      const r=document.createRange();r.selectNodeContents(n);
      for(const box of r.getClientRects()){
        if(box.width===0||box.height===0)continue;
        if(box.left<sr.left-2||box.right>sr.right+2||box.top<sr.top-2||box.bottom>sr.bottom+2)issues.push({text:n.textContent.trim().slice(0,100),type:'outside slide'});
        const source=slide.querySelector('.source').getBoundingClientRect();
        if(!el.closest('.source')&&box.bottom>source.top-6)issues.push({text:n.textContent.trim().slice(0,100),type:'overlaps source zone'});
      }
    }
    const images=[...slide.querySelectorAll('img')].map(i=>({src:i.getAttribute('src'),loaded:i.complete&&i.naturalWidth>0}));
    return {id,issues,images,notesHidden:[...slide.querySelectorAll('.speaker-note')].every(e=>getComputedStyle(e).display==='none')};
  },s.id);
  layouts.push(layout);
  assert(layout.notesHidden, s.id+': notes hidden');
  assert(layout.images.every(i=>i.loaded),s.id+': local images loaded');
}
await page.keyboard.press('Home');assert(await page.locator('#s1').isVisible(),'Home → first main');
await page.keyboard.press('Space');assert(await page.locator('#s2').isVisible(),'Space → next main');
await page.keyboard.press('ArrowRight');assert(await page.locator('#s3').isVisible(),'ArrowRight → next main');
for(const tab of ['input','reasons','result']){
 await page.locator(`[data-demo="${tab}"]`).click();
 assert(await page.locator('#demo-'+tab).isVisible(),'Scenario tab '+tab);
 await page.waitForTimeout(180);
  await page.screenshot({animations:'disabled',path:path.join(out,'s3-'+tab+'.png')});
}
await page.locator('#next').click();
for(let n=1;n<=5;n++) {await page.keyboard.press('ArrowRight');assert((await page.locator('#s4 .emphasis').getAttribute('data-step'))===String(n),'Architecture highlight '+n);}
await page.reload();assert(page.url().endsWith('#s4/5'),'Reload restores slide and highlight');
await page.keyboard.press('ArrowRight');assert(await page.locator('#s5').isVisible(),'After architecture steps → slide 5');
for(let n=1;n<=3;n++){await page.keyboard.press('ArrowRight');assert((await page.locator('#s5 .emphasis').getAttribute('data-step'))===String(n),'Score highlight '+n);}
await page.keyboard.press('ArrowLeft');assert((await page.locator('#s5 .emphasis').getAttribute('data-step'))==='2','ArrowLeft reverses highlight');
await page.keyboard.press('End');await page.keyboard.press('ArrowRight');await page.keyboard.press('Space');assert(await page.locator('#s7').isVisible(),'Final slide stays in main route');
await page.locator('#s7 [data-open="b1"]').click();assert(await page.locator('#b1').isVisible(),'Backup opens explicitly');
await page.reload();assert(await page.locator('#b1').isVisible(),'Backup survives refresh');
await page.keyboard.press('Escape');assert(await page.locator('#s7').isVisible(),'Escape returns to saved main');
await page.keyboard.press('Home');await page.keyboard.press('b');assert(await page.locator('#backup-dialog').isVisible(),'B opens backup menu');
await page.locator('#backup-dialog [data-open="b4"]').click();await page.locator('#return-main').click();assert(await page.locator('#s1').isVisible(),'Return preserves main origin');
await page.keyboard.press('n');assert(await page.locator('#notes-dialog').isVisible(),'N explicitly opens speaker notes');await page.keyboard.press('Escape');assert(!await page.locator('#notes-dialog').isVisible(),'Notes close with Escape');
await page.evaluate(()=>{location.hash='s4/0'});await page.waitForFunction(()=>!document.getElementById('s4').hidden);await page.keyboard.press('a');await page.keyboard.press('ArrowRight');assert(await page.locator('#s5').isVisible(),'Disabled steps preserve content and skip highlights');await page.keyboard.press('a');
await page.keyboard.press('f');await page.waitForTimeout(150);assert(await page.evaluate(()=>!!document.fullscreenElement),'F enters fullscreen');await page.keyboard.press('f');
await page.setViewportSize({width:1280,height:720});await page.keyboard.press('End');await page.waitForTimeout(180);
  await page.screenshot({animations:'disabled',path:path.join(out,'s7-1280.png')});
assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight),'1280×720: stage fits viewport');
await page.setViewportSize({width:1024,height:768});await page.waitForFunction(()=>document.getElementById('stage').getBoundingClientRect().width<=innerWidth);await page.keyboard.press('Home');assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth&&document.documentElement.scrollHeight<=innerHeight),'1024×768: letterboxing, no page overflow');
await page.emulateMedia({reducedMotion:'reduce'});assert(await page.locator('#progress').evaluate(e=>getComputedStyle(e).transitionDuration)==='0s','Reduced motion disables transitions');
assert(network.length===0,'No HTTP(S) requests while offline');assert(errors.length===0,'No browser JavaScript errors');
const report={checked_at:new Date().toISOString(),browser:await browser.version(),mode:'headless Chromium; software rendering (--disable-gpu); file://; offline=true',assertions,layouts,errors,network};
fs.writeFileSync(path.join(here,'browser-report.json'),JSON.stringify(report,null,2)+'\n');
assert(layouts.every(x=>x.issues.length===0),'All slides: no text outside safe area or overlapping source');
console.log(JSON.stringify({assertions:assertions.length,layoutIssues:layouts.filter(x=>x.issues.length),errors,network},null,2));
await browser.close();
