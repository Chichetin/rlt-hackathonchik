'use strict';
(() => {
  const stage = document.getElementById('stage');
  const slides = [...document.querySelectorAll('.slide')];
  const main = slides.filter(s => s.dataset.kind === 'main');
  const backup = slides.filter(s => s.dataset.kind === 'backup');
  const $ = id => document.getElementById(id);
  const motion = window.DeckMotion;
  const storage = { get(key) { try { return localStorage.getItem(key); } catch { return null; } }, set(key, value) { try { localStorage.setItem(key, value); } catch { /* file:// storage may be disabled */ } } };
  let current = main[0], step = 0, returnId = storage.get('rlt-return') || 's7';
  let noSteps = storage.get('rlt-no-steps') === 'true';
  const maxStep = () => Math.max(0, ...[...current.querySelectorAll('[data-step]')].map(n => Number(n.dataset.step)));
  function fit() {
    const scale = Math.min(innerWidth / 1600, innerHeight / 900);
    stage.style.transform = `scale(${scale})`;
    stage.style.left = `${(innerWidth - 1600 * scale) / 2}px`;
    stage.style.top = `${(innerHeight - 900 * scale) / 2}px`;
  }
  function render() {
    for (const s of slides) s.hidden = s !== current;
    const isMain = current.dataset.kind === 'main', group = isMain ? main : backup;
    $('counter').textContent = `${isMain ? '' : 'Q '}${group.indexOf(current) + 1} / ${group.length}`;
    $('step-counter').textContent = maxStep() && !noSteps ? `акцент ${step}/${maxStep()}` : '';
    $('return-main').hidden = isMain;
    $('previous').disabled = group.indexOf(current) === 0 && (!step || noSteps);
    $('next').disabled = group.indexOf(current) === group.length - 1 && (step >= maxStep() || noSteps);
    $('progress').style.width = `${(isMain ? main.indexOf(current) + 1 : main.findIndex(s => s.id === returnId) + 1) / main.length * 100}%`;
    current.querySelectorAll('[data-step]').forEach(el => {
      el.classList.toggle('emphasis', !noSteps && +el.dataset.step === step);
      el.classList.toggle('step-complete', !noSteps && +el.dataset.step < step);
    });
    document.body.classList.toggle('no-steps', noSteps);
    motion?.setDisabled(noSteps);
    $('motion').setAttribute('aria-pressed', String(noSteps));
    $('motion').firstChild.textContent = noSteps ? 'Анимации выкл. ' : 'Без анимаций ';
    document.title = `${current.dataset.title} — Митрандир`;
    const hash = `#${current.id}/${step}`;
    if (location.hash !== hash) history.replaceState(null, '', hash);
    storage.set('rlt-slide', `${current.id}/${step}`);
  }
  function show(id, wantedStep = 0, rememberOrigin = true) {
    const target = slides.find(s => s.id === id);
    if (!target) return;
    const previous = current;
    const direction = slides.indexOf(target) < slides.indexOf(previous) ? -1 : 1;
    if (rememberOrigin && current.dataset.kind === 'main' && target.dataset.kind === 'backup') {
      returnId = current.id; storage.set('rlt-return', returnId);
    }
    current = target; step = Math.max(0, Math.min(wantedStep, maxStep()));
    render();
    motion?.enter(current, previous, direction);
    if (step) motion?.accent(current, noSteps ? 0 : step, step);
  }
  function advance(direction) {
    if (!noSteps && direction > 0 && step < maxStep()) { const was = step; step++; render(); motion?.accent(current, step, was); return; }
    if (!noSteps && direction < 0 && step > 0) { const was = step; step--; render(); motion?.accent(current, step, was); return; }
    const group = current.dataset.kind === 'main' ? main : backup;
    const target = group[group.indexOf(current) + direction];
    if (target) show(target.id);
  }
  function restore() {
    const match = (location.hash.slice(1) || storage.get('rlt-slide') || 's1/0').match(/^([sb][1-7])(?:\/(\d+))?$/);
    if (match && slides.some(s => s.id === match[1])) show(match[1], Number(match[2] || 0), false);
    else show('s1');
  }
  function backToMain() { show(main.some(s => s.id === returnId) ? returnId : 's7'); }
  function openBackups() { $('backup-dialog').showModal(); }
  function openNotes() {
    $('notes-title').textContent = `${current.dataset.title}${+current.dataset.seconds ? ` · ${current.dataset.seconds} с` : ''}`;
    $('notes-content').innerHTML = current.querySelector('.speaker-note').innerHTML;
    $('notes-dialog').showModal();
  }
  function toggleSteps() { noSteps = !noSteps; storage.set('rlt-no-steps', String(noSteps)); render(); motion?.accent(current, noSteps ? 0 : step, step); }
  function replay() { motion?.enter(current, null); if (step) motion?.accent(current, noSteps ? 0 : step, 0); }
  async function fullscreen() {
    try { if (document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); }
    catch { $('announcement').textContent = 'Полноэкранный режим недоступен. Используйте F11 браузера.'; }
  }
  $('next').onclick = () => advance(1);
  $('previous').onclick = () => advance(-1);
  $('backups').onclick = openBackups;
  $('return-main').onclick = backToMain;
  $('notes').onclick = openNotes;
  $('motion').onclick = toggleSteps;
  $('fullscreen').onclick = fullscreen;
  $('replay').onclick = replay;
  document.querySelectorAll('[data-open]').forEach(button => button.onclick = () => {
    document.querySelectorAll('dialog[open]').forEach(d => d.close()); show(button.dataset.open);
  });
  document.querySelectorAll('[data-close]').forEach(button => button.onclick = () => button.closest('dialog').close());
  document.querySelectorAll('dialog').forEach(d => d.addEventListener('click', e => { if (e.target === d) { const r = d.getBoundingClientRect(); if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) d.close(); } }));
  function selectTab(button) {
    document.querySelectorAll('[data-demo]').forEach(b => { const chosen = b === button; b.setAttribute('aria-selected', String(chosen)); b.tabIndex = chosen ? 0 : -1; $(`demo-${b.dataset.demo}`).hidden = !chosen; });
    motion?.tab($(`demo-${button.dataset.demo}`));
  }
  document.querySelectorAll('[data-demo]').forEach(button => {
    button.onclick = () => selectTab(button);
    button.onkeydown = e => {
      if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) return;
      e.stopPropagation(); e.preventDefault();
      const tabs = [...document.querySelectorAll('[data-demo]')], dir = ['ArrowRight','ArrowDown'].includes(e.key) ? 1 : -1;
      const target = tabs[(tabs.indexOf(button) + dir + tabs.length) % tabs.length]; selectTab(target); target.focus();
    };
  });
  document.addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey || e.altKey || document.querySelector('dialog[open]')) return;
    if (e.target.closest('input,textarea,select,[contenteditable="true"]')) return;
    if (e.key === 'Escape' && current.dataset.kind === 'backup') { e.preventDefault(); backToMain(); return; }
    if (e.target.closest('button') && [' ', 'Enter'].includes(e.key)) return;
    const action = { ArrowRight: () => advance(1), ArrowDown: () => advance(1), PageDown: () => advance(1), ' ': () => advance(1), ArrowLeft: () => advance(-1), ArrowUp: () => advance(-1), PageUp: () => advance(-1), Home: () => show('s1'), End: () => show('s7'), b: openBackups, и: openBackups, n: openNotes, т: openNotes, a: toggleSteps, ф: toggleSteps, f: fullscreen, а: fullscreen, r: replay, к: replay }[e.key.length === 1 ? e.key.toLowerCase() : e.key];
    if (action) { e.preventDefault(); action(); }
  });
  addEventListener('resize', fit); addEventListener('hashchange', restore);
  fit(); restore();
})();
